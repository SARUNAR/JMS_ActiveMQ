package anoop_activemq;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.jms.ConnectionFactory;

public class Main {

    public static void main(String[] args) throws Exception {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
                "application-context.xml");

        try {
            ConnectionFactory connectionFactory = (ConnectionFactory) context.getBean("connectionFactory");
            connectionFactory.createConnection();
            while (true) {

            }
        } finally {
            context.close();
        }
    }

}

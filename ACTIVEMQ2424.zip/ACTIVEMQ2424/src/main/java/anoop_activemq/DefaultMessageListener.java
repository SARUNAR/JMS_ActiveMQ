package anoop_activemq;

import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.jms.support.converter.MessageConverter;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.Session;

public class DefaultMessageListener implements MessageListener {

    private final JmsTemplate jmsTemplate;

    private final MessageConverter messageConverter;

    public DefaultMessageListener(JmsTemplate jmsTemplate, MessageConverter messageConverter) {
        this.jmsTemplate = jmsTemplate;
        this.messageConverter = messageConverter;
    }

    public void onMessage(Message message) {
        try {
            final String messageReceived = (String) messageConverter.fromMessage(message);

            System.out.println("Message received: " + messageReceived);

            jmsTemplate.send(new MessageCreator() {
                public Message createMessage(Session session) throws JMSException {
                    if (messageReceived.length() % 2 == 0) {
                        return session.createTextMessage("Message has even no of characters. No of chars - " + messageReceived.length());
                    } else {
                        return session.createTextMessage("Message has odd no of characters. No of chars - " + messageReceived.length());
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
